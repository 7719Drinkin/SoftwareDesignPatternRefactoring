public interface ISaveManager
{
    void LoadData(GameData data);
    void SaveData(ref GameData data);
}
