using UnityEngine;

public class Spark_Controller : MonoBehaviour
{
    private void DestroyMe() => Destroy(gameObject);
}
