public interface IEnemyStates
{
    /// <summary>
    /// 返回敌人应当进入的初始状态
    /// </summary>
    EnemyState InitialState { get; }
}

