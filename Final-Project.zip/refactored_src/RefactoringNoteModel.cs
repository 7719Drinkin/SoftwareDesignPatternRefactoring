// 重构注释模板
// 重构好代码后，只需将此部分放在重构后的代码的头/尾部即可
// 将自己重构了的代码放进patterns的对应文件夹下，并以自己所使用的patternType命名自己的文件夹
// 例如 patterns/creational/factoryMethod/


/***************************************************************
 *  Refactored with: [Design Pattern Name]
 *  Pattern Type: [Creational / Structural / Behavioral / Additional]
 *
 *  Document Reference:
 *  - See report section “2.2.x Pattern Name (Pattern Type)”
 ***************************************************************/

// 此处是重构代码部分

/***************************************************************
 * End
 ***************************************************************/